package bank;

public enum TypeOperator {
	ATM,
	CLIENT,
	AGENT,
	ADMINISTRATOR
}
